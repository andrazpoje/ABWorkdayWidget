package com.dante.workcycle.domain.usecase

import com.dante.workcycle.data.repository.WorkLogRepository
import com.dante.workcycle.domain.model.WorkLog

class SaveWorkLogUseCase(
    private val repository: WorkLogRepository
) {
    suspend operator fun invoke(log: WorkLog): Long {
        return repository.save(log)
    }
}