package com.dante.workcycle.domain.usecase

import com.dante.workcycle.data.repository.WorkLogRepository
import com.dante.workcycle.domain.model.WorkLog
import java.time.LocalDate

class GetWorkLogForDateUseCase(
    private val repository: WorkLogRepository
) {
    suspend operator fun invoke(date: LocalDate): WorkLog? {
        return repository.getByDate(date)
    }
}