package com.dante.abworkdaywidget

import android.content.Context
import androidx.core.content.edit

object CycleThemeManager {

    private const val PREFS = "abprefs"
    private const val KEY_THEME = "cycle_theme"

    const val THEME_CLASSIC = "classic"
    const val THEME_PASTEL = "pastel"
    const val THEME_DARK = "dark"

    fun saveTheme(context: Context, theme: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit {
                putString(KEY_THEME, theme)
            }
    }

    fun loadTheme(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_THEME, THEME_CLASSIC) ?: THEME_CLASSIC
    }

}