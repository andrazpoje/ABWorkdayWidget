package com.dante.abworkdaywidget

object Prefs {

    const val NAME = "ab_prefs"

    // cycle
    const val KEY_CYCLE_DAYS = "cycle_days"
    const val KEY_CYCLE_START_DATE = "cycle_start_date"

    // rules
    const val KEY_SKIP_SATURDAYS = "skipSaturdays"
    const val KEY_SKIP_SUNDAYS = "skipSundays"
    const val KEY_SKIP_HOLIDAYS = "skipHolidays"

    // overrides
    const val KEY_OVERRIDE_SKIPPED = "overrideSkippedDays"
    const val KEY_SKIPPED_LABEL = "skippedDayLabel"

    // theme
    const val KEY_THEME = "cycle_theme"

    // country
    const val KEY_HOLIDAY_COUNTRY = "holiday_country"
    const val KEY_COUNTRY_MANUAL = "country_manual"
}