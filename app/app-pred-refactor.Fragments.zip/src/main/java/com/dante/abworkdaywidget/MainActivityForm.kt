package com.dante.abworkdaywidget

import android.content.Context
import android.content.res.ColorStateList
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.Filterable
import android.widget.Toast
import androidx.core.graphics.ColorUtils
import com.dante.abworkdaywidget.util.sanitizeLabel
import com.google.android.material.chip.Chip
import java.util.Locale

fun MainActivity.validateCycleInput(): Boolean {
    val raw = cycleDaysEdit.text?.toString().orEmpty().trim()
    val parts = raw.split(",").map { it.trim() }

    if (raw.isBlank() || parts.all { it.isEmpty() }) {
        cycleDaysInputLayout.error = getString(R.string.error_cycle_empty)
        return false
    }

    if (parts.any { it.isEmpty() }) {
        cycleDaysInputLayout.error = getString(R.string.error_cycle_empty_item)
        return false
    }

    if (parts.size > MainActivity.MAX_CYCLE_ITEMS) {
        cycleDaysInputLayout.error = getString(
            R.string.error_cycle_too_many,
            parts.size,
            MainActivity.MAX_CYCLE_ITEMS
        )
        return false
    }

    if (parts.any { it.length > MainActivity.MAX_LABEL_LENGTH }) {
        cycleDaysInputLayout.error = resources.getQuantityString(
            R.plurals.error_label_too_long,
            MainActivity.MAX_LABEL_LENGTH,
            MainActivity.MAX_LABEL_LENGTH
        )
        return false
    }

    val distinct = parts.map { it.lowercase(Locale.getDefault()) }.toSet()
    if (distinct.size != parts.size) {
        cycleDaysInputLayout.error = getString(R.string.error_cycle_duplicates)
        return false
    }

    cycleDaysInputLayout.error = null
    return true
}

private fun MainActivity.createNoFilterAdapter(items: List<String>): ArrayAdapter<String> {
    return object : ArrayAdapter<String>(
        this,
        android.R.layout.simple_list_item_1,
        items
    ), Filterable {

        override fun getFilter(): Filter {
            return object : Filter() {
                override fun performFiltering(constraint: CharSequence?): FilterResults {
                    return FilterResults().apply {
                        values = items
                        count = items.size
                    }
                }

                override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                    clear()
                    addAll(items)
                    notifyDataSetChanged()
                }

                override fun convertResultToString(resultValue: Any?): CharSequence {
                    return resultValue as String
                }
            }
        }
    }
}

fun MainActivity.buildCountryDisplayList(
    detectedCode: String,
    isManual: Boolean
): List<String> {
    return supportedCountries.map {
        HolidayManager.getCountryDisplayNameWithAutoDetected(
            context = this,
            countryCode = it.code,
            isAutoDetected = !isManual && it.code == detectedCode
        )
    }
}

fun parseCycleLabels(raw: String): List<String> {
    return raw.split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .mapIndexed { index, label ->
            sanitizeLabel(label, "Day ${index + 1}").take(MainActivity.MAX_LABEL_LENGTH)
        }
        .take(MainActivity.MAX_CYCLE_ITEMS)
}

fun MainActivity.getCurrentCycleLabelsFromInput(): List<String> {
    return parseCycleLabels(cycleDaysEdit.text?.toString().orEmpty())
}

fun MainActivity.getCurrentCycleInputState(): Pair<List<String>, String> {
    val currentCycle = parseCycleLabels(cycleDaysEdit.text?.toString().orEmpty())
    val currentFirstDay = firstCycleDayDropdown.text?.toString()?.trim().orEmpty()
    return currentCycle to currentFirstDay
}

fun MainActivity.wouldPresetChangeCurrentState(preset: CyclePreset): Boolean {
    val (currentCycle, currentFirstDay) = getCurrentCycleInputState()

    val normalizedPresetCycle = preset.cycleDaysProvider(this).map {
        sanitizeLabel(it, "").take(MainActivity.MAX_LABEL_LENGTH)
    }

    val normalizedPresetFirstDay = sanitizeLabel(
        preset.defaultFirstDayProvider(this),
        normalizedPresetCycle.firstOrNull() ?: ""
    ).take(MainActivity.MAX_LABEL_LENGTH)

    return currentCycle != normalizedPresetCycle || currentFirstDay != normalizedPresetFirstDay
}

fun MainActivity.applyPreset(preset: CyclePreset) {
    val labels = preset.cycleDaysProvider(this)
    val firstDay = preset.defaultFirstDayProvider(this)

    cycleDaysEdit.setText(labels.joinToString(", "))
    refreshFirstCycleDayDropdown(firstDay)
    clearDateCheckResult()
    validateCycleInput()
    updatePresetSelectionState(markAsChanged = true)
    updateTodayStatus()
    updateCyclePreview()

    Toast.makeText(
        this,
        getString(R.string.preset_applied, getString(preset.nameRes)),
        Toast.LENGTH_SHORT
    ).show()
}

private fun MainActivity.getChipColorForLabel(
    label: String,
    cycleLabels: List<String>
): Int {
    return try {
        CycleColorHelper.getBackgroundColor(this, label, cycleLabels)
    } catch (_: Exception) {
        getColor(android.R.color.darker_gray)
    }
}

private fun MainActivity.renderFirstCycleDayChips(
    cycleLabels: List<String>,
    selectedValue: String
) {
    firstCycleDayChipGroup.removeAllViews()

    if (cycleLabels.isEmpty()) {
        firstCycleDayChipGroup.visibility = View.GONE
        return
    }

    firstCycleDayChipGroup.visibility = View.VISIBLE

    cycleLabels.forEach { label ->
        val fillColor = getChipColorForLabel(label, cycleLabels)
        val textColor = CycleColorHelper.getTextColorForBackground(fillColor)
        val unselectedBackground = ColorUtils.setAlphaComponent(fillColor, 40)
        val unselectedStroke = ColorUtils.setAlphaComponent(fillColor, 120)

        val backgroundStates = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                fillColor,
                unselectedBackground
            )
        )

        val textStates = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                textColor,
                fillColor
            )
        )

        val strokeStates = ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                fillColor,
                unselectedStroke
            )
        )

        val chip = Chip(this).apply {
            id = View.generateViewId()
            text = label
            isCheckable = true
            isClickable = true
            isCheckedIconVisible = false
            setEnsureMinTouchTargetSize(false)
            isChecked = label == selectedValue

            chipBackgroundColor = backgroundStates
            setTextColor(textStates)
            chipStrokeColor = strokeStates
            chipStrokeWidth = resources.displayMetrics.density * 1f

            setOnClickListener {
                firstCycleDayDropdown.setText(label, false)
                clearDateCheckResult()
                updatePresetSelectionState(markAsChanged = true)
                updateTodayStatus()
                updateCyclePreview()
            }
        }

        firstCycleDayChipGroup.addView(chip)
    }
}

fun MainActivity.refreshFirstCycleDayDropdown(preferredValue: String? = null) {
    val cycleLabels = getCurrentCycleLabelsFromInput()

    val adapter = createNoFilterAdapter(cycleLabels)
    firstCycleDayDropdown.setAdapter(adapter)

    if (cycleLabels.isEmpty()) {
        firstCycleDayDropdown.setText("", false)
        firstCycleDayDropdown.isEnabled = false
        renderFirstCycleDayChips(emptyList(), "")
        return
    }

    firstCycleDayDropdown.isEnabled = true

    val currentValue = preferredValue
        ?: firstCycleDayDropdown.text?.toString()?.trim().orEmpty()

    val finalValue = when {
        currentValue in cycleLabels -> currentValue
        else -> cycleLabels.first()
    }

    firstCycleDayDropdown.setText(finalValue, false)
    renderFirstCycleDayChips(cycleLabels, finalValue)
}

fun MainActivity.setupFirstCycleDayDropdown() {
    firstCycleDayDropdown.keyListener = null

    firstCycleDayDropdown.setOnClickListener {
        if (firstCycleDayDropdown.adapter != null && firstCycleDayDropdown.adapter.count > 0) {
            firstCycleDayDropdown.showDropDown()
        }
    }

    firstCycleDayDropdown.setOnItemClickListener { _, _, _, _ ->
        val selected = firstCycleDayDropdown.text?.toString()?.trim().orEmpty()
        refreshFirstCycleDayDropdown(selected)
        clearDateCheckResult()
        updatePresetSelectionState(markAsChanged = true)
        updateTodayStatus()
        updateCyclePreview()
    }
}

fun MainActivity.setupPresetDropdown() {
    val presets = CyclePresetProvider.getPresets()
    val names = presets.map { getString(it.nameRes) } + getString(R.string.preset_custom)

    val adapter = createNoFilterAdapter(names)

    presetDropdown.setAdapter(adapter)
    presetDropdown.keyListener = null

    presetDropdown.setOnClickListener {
        presetDropdown.showDropDown()
    }

    presetDropdown.setOnItemClickListener { _, _, _, _ ->
        val selectedName = presetDropdown.text?.toString()?.trim().orEmpty()

        if (selectedName == getString(R.string.preset_custom)) {
            updatePresetSelectionState(markAsChanged = true)
            return@setOnItemClickListener
        }

        val preset = CyclePresetProvider.findByDisplayName(this, selectedName)
            ?: return@setOnItemClickListener

        if (!wouldPresetChangeCurrentState(preset)) {
            updatePresetSelectionState()
            return@setOnItemClickListener
        }

        applyPreset(preset)
    }
}

fun MainActivity.updatePresetSelectionState(markAsChanged: Boolean = false) {
    val matchedPreset = CyclePresetProvider.getPresets().firstOrNull { preset ->
        !wouldPresetChangeCurrentState(preset)
    }

    val presetText = matchedPreset
        ?.let { getString(it.nameRes) }
        ?: getString(R.string.preset_custom)

    if (presetDropdown.text?.toString() != presetText) {
        presetDropdown.setText(presetText, false)
    }

    if (markAsChanged) {
        markUnsavedChanges()
    }
}

fun MainActivity.setupHolidayCountryDropdown() {
    supportedCountries = HolidayManager.supportedCountries

    val prefs = getSharedPreferences(AppPrefs.NAME, Context.MODE_PRIVATE)
    val detectedCode = HolidayManager.getSelectedCountry(this)
    val isManual = prefs.getBoolean(AppPrefs.KEY_COUNTRY_MANUAL, false)

    val displayItems = buildCountryDisplayList(detectedCode, isManual)

    val adapter = createNoFilterAdapter(displayItems)

    holidayCountryDropdown.setAdapter(adapter)
    holidayCountryDropdown.keyListener = null
    holidayCountryDropdown.setOnClickListener {
        holidayCountryDropdown.showDropDown()
    }
}